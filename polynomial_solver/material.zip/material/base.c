#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_STRING 256

double * read_constants(int * degree) {
	int i;
	scanf(" %d", degree);
	double * polynomial = (double *) malloc(sizeof(double) * (*degree + 1));
	for (i = *degree; i >= 0; i--)
		scanf(" %lf", &polynomial[i]);
	return polynomial;
}

double * read_instances(int * num) {
	int i;
	scanf(" %d", num);
	double * instances = (double *) malloc(sizeof(double) * (*num));
	for (i = 0; i < *num; i++)
		scanf(" %lf", &instances[i]);
	return instances;
}

void print_polynomial(double * polynomial, int degree) {
	int i = 0, firsttime = 1;
	for (i = degree; i >= 0; i--) {
		char str[MAX_STRING] = "";
		double factor = polynomial[i];
		
		if (factor != 0) {
			if (firsttime)
				sprintf(str, "%.1lf", factor);
			else
				if (factor < 0)
					sprintf(str, " - %.1lf", -factor);
				else
					sprintf(str, " + %.1lf", factor);
			
			if (str[0] != '\0') {
				if (i > 0) {
					printf("%s x^%d", str, i);
				}
				else
					printf("%s", str);
				str[0] = '\0';
				firsttime = 0;
			}
		}
	}
}


void evaluate(double * polynomial, int degree, double * inputlist, int num_inputs, double (evaluate_function)(double *, int, double)) {
	int i;
	printf("p(x) = ");
	print_polynomial(polynomial, degree);
	printf("\n");
	for (i = 0; i < num_inputs; i++) {
		double input = inputlist[i];
		double output = evaluate_function(polynomial, degree, input);
		printf("p(%.1lf) = %.1lf\n", input, output);
	}
}


/* NOTA: esta função não está de acordo com os requisitos do enunciado.
   Leia cuidadosamente as instruções relativamente ao formato da saída.
*/
int do_the_work(void) {
	int degree, num_instances;
    double * polynomial = read_constants(&degree);
	double * instances = read_instances(&num_instances);
	clock_t ticks1, ticks2;	
	
	printf("Basic evaluation\n");
	ticks1 = clock();
	evaluate(polynomial, degree, instances, num_instances, evaluate_basic);
	ticks2 = clock();
	printf("seconds basic = %lf\n", 1.0 * (ticks2 - ticks1) / CLOCKS_PER_SEC);
	
	printf("Horner evaluation\n");
	ticks1 = clock();
	evaluate(polynomial, degree, instances, num_instances, evaluate_horner);
	ticks2 = clock();
	printf("seconds horner = %lf\n", 1.0 * (ticks2 - ticks1) / CLOCKS_PER_SEC);
	
	printf("Prefix evaluation\n");
	ticks1 = clock();
	evaluate(polynomial, degree, instances, num_instances, evaluate_prefix);
	ticks2 = clock();
	printf("seconds prefix = %lf\n", 1.0 * (ticks2 - ticks1) / CLOCKS_PER_SEC);
	
	free(polynomial);
	free(instances);
    return 0;
}




