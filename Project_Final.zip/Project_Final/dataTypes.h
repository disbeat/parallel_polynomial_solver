#ifndef _DATATYPES_H
#define _DATATYPES_H

#define NUM_THREADS 2




typedef double CoefType;
typedef double TestType;
typedef double ResultType;


#endif